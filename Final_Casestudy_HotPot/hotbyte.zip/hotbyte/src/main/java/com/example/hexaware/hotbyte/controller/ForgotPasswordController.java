package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import com.example.hexaware.hotbyte.service.OtpService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class ForgotPasswordController {

    @Autowired
    private OtpService otpService;

    @Autowired
    private UsersRepository usersRepository;

    // ✅ 1. Request OTP
    @PostMapping("/request-otp")
    public String requestOtp(@RequestParam String email) {
        Users user = usersRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));

        String otp = otpService.generateOtp(email);
        otpService.sendOtpEmail(email, otp);

        return "✅ OTP sent to " + email;
    }

    // ✅ 2. Verify OTP
    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam String email, @RequestParam String otp) {
        boolean isValid = otpService.validateOtp(email, otp);
        return isValid ? "✅ OTP verified" : "❌ Invalid or expired OTP";
    }

    // ✅ 3. Reset password (PLAIN TEXT VERSION)
    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String email,
                                @RequestParam String newPassword,
                                @RequestParam String otp) {
        if (!otpService.validateOtp(email, otp)) {
            return "❌ OTP invalid or expired";
        }

        Users user = usersRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));

        user.setPassword(newPassword);  // ✅ Store as plain text
        usersRepository.save(user);

        return "✅ Password reset successful";
    }

}
