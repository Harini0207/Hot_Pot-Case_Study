package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.entity.*;
import com.example.hexaware.hotbyte.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class CartItemEntityTest {

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Test
    void testCartItemGettersSetters() {
        Users user = new Users("cartuser@mail.com", "cart123", "Cart User", "8888888888", "Cart City", "Female");
        user.setRole("user");

        Restaurant restaurant = new Restaurant();

        MenuItem menuItem = new MenuItem("Samosa", "Tasty snack", "Snacks", new BigDecimal("15.00"), "image.jpg", true, true, restaurant);

        CartItem cartItem = new CartItem(user, menuItem, 3);

        assertEquals(user, cartItem.getUser());
        assertEquals(menuItem, cartItem.getMenuItem());
        assertEquals(3, cartItem.getQuantity());
    }

    @Test
    void testCartItemRepositorySaveAndFind() {
        Users user = new Users("cartrepo@mail.com", "pass", "Cart Repo User", "7777777777", "City X", "Male");
        user.setRole("user");
        usersRepository.save(user);

        Restaurant rest = new Restaurant();
        restaurantRepository.save(rest);

        MenuItem menu = new MenuItem("Fries", "Crispy fries", "Snacks", new BigDecimal("50.00"), null, true, true, rest);
        menuItemRepository.save(menu);

        CartItem item = new CartItem(user, menu, 2);
        cartItemRepository.save(item);

        Optional<CartItem> result = cartItemRepository.findById(item.getId());
        assertTrue(result.isPresent());
        assertEquals("Fries", result.get().getMenuItem().getName());
        assertEquals(2, result.get().getQuantity());
    }
}
