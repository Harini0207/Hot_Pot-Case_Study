package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.Orders;
import com.example.hexaware.hotbyte.service.OrdersService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrdersRestController {

    @Autowired
    private OrdersService ordersService;

    @PreAuthorize("hasAnyRole('USER', 'RESTAURANT', 'ADMIN')")
    @PostMapping("/place")
    public Orders placeOrder(@Valid @RequestBody Orders incomingOrder) {
        return ordersService.placeOrder(incomingOrder);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Orders> getAllOrders() {
        return ordersService.getAllOrders();
    }

    @PreAuthorize("hasAnyRole('USER', 'RESTAURANT', 'ADMIN')")
    @GetMapping("/{id}")
    public Orders getOrderById(@PathVariable int id) {
        return ordersService.getOrderById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    @PreAuthorize("hasAnyRole('USER', 'RESTAURANT', 'ADMIN')")
    @GetMapping("/user/{email}")
    public List<Orders> getOrdersByUserEmail(@PathVariable String email) {
        return ordersService.getOrdersByUserEmail(email);
    }

    @PreAuthorize("hasAnyRole('RESTAURANT', 'ADMIN')")
    @GetMapping("/restaurant/id/{restaurantId}")
    public List<Orders> getOrdersByRestaurantId(@PathVariable int restaurantId) {
        return ordersService.getOrdersByRestaurantId(restaurantId);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Orders updateOrder(@PathVariable int id, @Valid @RequestBody Orders updatedOrder) {
        return ordersService.updateOrder(id, updatedOrder);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable int id) {
        ordersService.deleteOrder(id);
        return "Order deleted successfully";
    }
    @PreAuthorize("hasAnyRole('USER', 'RESTAURANT', 'ADMIN')")
    @PutMapping("/{id}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable int id) {
        System.out.println("▶️ Received cancel request for order ID: " + id);
        try {
            boolean success = ordersService.cancelOrder(id);
            System.out.println("▶️ Service returned: " + success);
            if (success) {
                return ResponseEntity.ok("Order cancelled successfully.");
            } else {
                return ResponseEntity.badRequest().body("❌ Order cannot be cancelled after 15 minutes or it's already cancelled.");
            }
        } catch (Exception ex) {
            ex.printStackTrace(); // Log full stack trace
            return ResponseEntity.status(500).body("❌ Server error: " + ex.getMessage());
        }
    }
    }


