package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.repository.MenuItemRepository;
import com.example.hexaware.hotbyte.repository.RestaurantRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class MenuItemEntityTest {

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Test
    void testMenuItemGettersSetters() {
        Restaurant restaurant = new Restaurant();
        restaurant.setName("Testaurant");
        restaurant.setAddress("123 Street");
        restaurant.setContactNumber("1234567890");

        MenuItem item = new MenuItem(
                "Paneer Pizza", "Delicious cheesy paneer", "Pizza",
                new BigDecimal("299.99"), "img.jpg", true, true, restaurant
        );

        assertEquals("Paneer Pizza", item.getName());
        assertEquals("Delicious cheesy paneer", item.getDescription());
        assertEquals("Pizza", item.getCategory());
        assertEquals(new BigDecimal("299.99"), item.getPrice());
        assertEquals("img.jpg", item.getImageUrl());
        assertTrue(item.isVeg());
        assertTrue(item.isAvailability());
        assertEquals(restaurant, item.getRestaurant());
    }

    @Test
    void testMenuItemRepositorySaveAndFetch() {
        Restaurant restaurant = new Restaurant();
        restaurant.setName("RepoResto");
        restaurant.setAddress("Repo Lane");
        restaurant.setContactNumber("9876543210");
        restaurantRepository.save(restaurant);

        MenuItem item = new MenuItem(
                "Burger", "Tasty Veg Burger", "Snacks",
                new BigDecimal("99.00"), "burger.jpg", true, true, restaurant
        );
        menuItemRepository.save(item);

        Optional<MenuItem> result = menuItemRepository.findById(item.getId());
        assertTrue(result.isPresent());
        assertEquals("Burger", result.get().getName());
        assertEquals("Snacks", result.get().getCategory());
        assertEquals(restaurant.getId(), result.get().getRestaurant().getId());
    }
}
