package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.*;
import com.example.hexaware.hotbyte.repository.*;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class OrdersService {

    @Autowired
    private OrdersRepository orderRepository;

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    public Orders placeOrder(Orders incomingOrder) {
        try {
            String userEmail = incomingOrder.getUser() != null ? incomingOrder.getUser().getEmail() : null;
            if (userEmail == null) throw new RuntimeException("User email is required");

            Users user = userRepository.findByEmail(userEmail)
                    .orElseThrow(() -> new RuntimeException("User not found: " + userEmail));

            Orders order = new Orders();
            order.setUser(user);
            order.setShippingAddress(incomingOrder.getShippingAddress());
            order.setPaymentMethod(incomingOrder.getPaymentMethod());
            order.setStatus("Placed");
            order.setOrderDate(LocalDateTime.now());

            BigDecimal total = BigDecimal.ZERO;
            List<OrderItem> finalItems = new ArrayList<>();
            Restaurant restaurant = null;

            for (OrderItem item : incomingOrder.getOrderItems()) {
                MenuItem menuItem = menuItemRepository.findById(item.getMenuItem().getId())
                        .orElseThrow(() -> new RuntimeException("Menu item not found: " + item.getMenuItem().getId()));

                if (restaurant == null) {
                    restaurant = menuItem.getRestaurant();
                }

                OrderItem orderItem = new OrderItem();
                orderItem.setMenuItem(menuItem);
                orderItem.setQuantity(item.getQuantity());
                orderItem.setPrice(menuItem.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));
                orderItem.setOrder(order);
                finalItems.add(orderItem);
                total = total.add(orderItem.getPrice());
            }

            order.setOrderItems(finalItems);
            order.setTotalAmount(total);
            order.setRestaurant(restaurant);

            Payment payment = new Payment();
            payment.setOrder(order);
            payment.setAmount(total);
            payment.setMethod(order.getPaymentMethod());
            payment.setStatus("Pending");
            order.setPayment(payment);

            return orderRepository.save(order);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Order placement failed: " + e.getMessage());
        }
    }

    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Orders> getOrderById(int id) {
        return orderRepository.findById(id);
    }

    public List<Orders> getOrdersByUserEmail(String email) {
        return orderRepository.findByUserEmail(email);
    }

    public List<Orders> getOrdersByRestaurantId(int restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RuntimeException("Restaurant not found with ID: " + restaurantId));
        return orderRepository.findByRestaurant(restaurant);
    }

    public void deleteOrder(int id) {
        if (!orderRepository.existsById(id)) {
            throw new RuntimeException("Order not found with ID: " + id);
        }
        orderRepository.deleteById(id);
    }

    public Orders updateOrder(int id, Orders updatedOrder) {
        Orders existingOrder = getOrderById(id)
                .orElseThrow(() -> new RuntimeException("Order not found: " + id));

        existingOrder.setShippingAddress(updatedOrder.getShippingAddress());
        existingOrder.setPaymentMethod(updatedOrder.getPaymentMethod());
        existingOrder.setStatus(updatedOrder.getStatus());

        return orderRepository.save(existingOrder);
    }

    // ✅ Corrected cancelOrder method
    public boolean cancelOrder(int orderId) {
        Orders order = orderRepository.findById(orderId)
                .orElseThrow(() -> new EntityNotFoundException("Order not found"));

        if ("Cancelled".equalsIgnoreCase(order.getStatus())) return false;

        LocalDateTime now = LocalDateTime.now();
        Duration diff = Duration.between(order.getOrderDate(), now);

        if (diff.toMinutes() <= 15) {
            order.setStatus("Cancelled");
            orderRepository.save(order);
            return true;
        }

        return false; // Too late to cancel
    }
}
