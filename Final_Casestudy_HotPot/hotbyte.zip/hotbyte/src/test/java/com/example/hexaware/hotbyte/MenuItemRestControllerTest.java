package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.MenuItemRestController;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.MenuItemService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(MenuItemRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class MenuItemRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MenuItemService menuItemService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testGetAllMenuItems() throws Exception {
        MenuItem item = new MenuItem();
        item.setId(1);
        item.setName("Pizza");
        item.setPrice(BigDecimal.valueOf(200));

        Mockito.when(menuItemService.getAllMenuItems()).thenReturn(List.of(item));

        mockMvc.perform(get("/api/menu-items"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Pizza"));
    }

    @Test
    void testGetMenuItemById() throws Exception {
        MenuItem item = new MenuItem();
        item.setId(2);
        item.setName("Burger");

        Mockito.when(menuItemService.getMenuItemById(2)).thenReturn(item);

        mockMvc.perform(get("/api/menu-items/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Burger"));
    }

    @Test
    void testGetMenuItemsByRestaurantId() throws Exception {
        MenuItem item = new MenuItem();
        item.setId(3);
        item.setName("Pasta");

        Mockito.when(menuItemService.getMenuItemsByRestaurantId(1)).thenReturn(List.of(item));

        mockMvc.perform(get("/api/menu-items/restaurant/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Pasta"));
    }

    @Test
    void testFilterMenuItems() throws Exception {
        MenuItem item = new MenuItem();
        item.setId(4);
        item.setName("Salad");
        item.setVeg(true);

        Mockito.when(menuItemService.filterMenuItems("Salads", "veg", "100-300", "salad"))
                .thenReturn(List.of(item));

        mockMvc.perform(get("/api/menu-items/filter")
                        .param("category", "Salads")
                        .param("dietType", "veg")
                        .param("priceRange", "100-300")
                        .param("keyword", "salad"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Salad"));
    }

    @Test
    void testCreateMenuItem() throws Exception {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(1);
        restaurant.setName("Foodies Hub");

        MenuItem input = new MenuItem("Pizza", "Cheesy", "Fast Food",
                BigDecimal.valueOf(250), "image.jpg", true, true, restaurant);

        MenuItem saved = new MenuItem("Pizza", "Cheesy", "Fast Food",
                BigDecimal.valueOf(250), "image.jpg", true, true, restaurant);
        saved.setId(5);

        Mockito.when(menuItemService.createMenuItem(any(MenuItem.class))).thenReturn(saved);

        mockMvc.perform(post("/api/menu-items")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.name").value("Pizza"));
    }

    @Test
    void testUpdateMenuItem() throws Exception {
        Map<String, Object> payload = Map.of(
                "name", "Updated Pizza",
                "description", "Spicy Cheese",
                "category", "Fast Food",
                "price", "299.99",
                "imageUrl", "updated.jpg",
                "veg", true,
                "availability", true,
                "restaurantId", 1
        );

        MenuItem updated = new MenuItem();
        updated.setId(6);
        updated.setName("Updated Pizza");
        updated.setPrice(BigDecimal.valueOf(299.99));

        Mockito.when(menuItemService.updateMenuItem(eq(6), anyMap())).thenReturn(updated);

        mockMvc.perform(put("/api/menu-items/6")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated Pizza"));
    }

    @Test
    void testDeleteMenuItem() throws Exception {
        Mockito.doNothing().when(menuItemService).deleteMenuItem(7);

        mockMvc.perform(delete("/api/menu-items/7"))
                .andExpect(status().isOk())
                .andExpect(content().string("Menu item deleted successfully."));
    }
}
