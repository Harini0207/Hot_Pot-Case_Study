package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UsersRestController {

    @Autowired
    private UserService userService;

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Users> getAllUsers() {
        return userService.getAllUsers();
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'USER', 'RESTAURANT')")
    @GetMapping("/{email}")
    public Users getUserByEmail(@PathVariable String email) {
        return userService.getUserByEmail(email);
    }

    @PostMapping
    public Users registerUser(@Valid @RequestBody Users user) {
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public String login(@Valid @RequestBody Users credentials) {
        return userService.loginUser(credentials);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{email}")
    public String deleteUser(@PathVariable String email) {
        return userService.deleteUser(email);
    }

    // ✅ NEW: Update user by email
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{email}")
    public Users updateUser(@PathVariable String email, @RequestBody Users updatedUser) {
        return userService.updateUser(email, updatedUser);
    }
}
