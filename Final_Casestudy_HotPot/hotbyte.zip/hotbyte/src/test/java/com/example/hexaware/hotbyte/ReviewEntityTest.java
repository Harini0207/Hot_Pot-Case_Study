package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Review;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.repository.MenuItemRepository;
import com.example.hexaware.hotbyte.repository.ReviewRepository;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ReviewEntityTest {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Test
    void testReviewGettersSetters() {
        Users user = new Users();
        MenuItem menuItem = new MenuItem();
        Review review = new Review(user, menuItem, 4, "Tasty and hot");

        assertEquals(4, review.getRating());
        assertEquals("Tasty and hot", review.getComment());
        assertEquals(user, review.getUser());
        assertEquals(menuItem, review.getMenuItem());
        assertNotNull(review.getReviewDate());
    }

    @Test
    void testReviewRepositorySaveAndFind() {
        Users user = new Users();
        user.setEmail("reviewtest@example.com");
        user.setName("ReviewUser");
        user.setPassword("pass123");
        usersRepository.save(user);

        MenuItem menuItem = new MenuItem();
        menuItem.setName("Test Item");
        menuItem.setPrice(java.math.BigDecimal.valueOf(100));
        menuItemRepository.save(menuItem);

        Review review = new Review(user, menuItem, 5, "Excellent!");
        reviewRepository.save(review);

        Optional<Review> result = reviewRepository.findById(review.getId());
        assertTrue(result.isPresent());
        assertEquals("Excellent!", result.get().getComment());
        assertEquals(5, result.get().getRating());
        assertEquals(user.getEmail(), result.get().getUser().getEmail());
        assertEquals(menuItem.getName(), result.get().getMenuItem().getName());
    }
}
