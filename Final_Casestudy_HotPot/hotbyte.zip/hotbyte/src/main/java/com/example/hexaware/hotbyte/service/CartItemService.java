package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.CartItem;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.repository.CartItemRepository;
import com.example.hexaware.hotbyte.repository.MenuItemRepository;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartItemService {

    @Autowired
    private CartItemRepository cartItemRepo;

    @Autowired
    private UsersRepository usersRepo;

    @Autowired
    private MenuItemRepository menuItemRepo;

    public List<CartItem> getAllCartItems() {
        return cartItemRepo.findAll();
    }

    public List<CartItem> getCartItemsByUser(String email) {
        return cartItemRepo.findByUserEmail(email);
    }

    public CartItem addCartItem(String userEmail, int menuItemId, int quantity) {
        Users user = usersRepo.findById(userEmail)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        MenuItem menuItem = menuItemRepo.findById(menuItemId)
                .orElseThrow(() -> new EntityNotFoundException("Menu item not found"));

        CartItem cartItem = new CartItem(user, menuItem, quantity);
        return cartItemRepo.save(cartItem);
    }

    public CartItem updateCartItem(int id, int quantity) {
        CartItem cartItem = cartItemRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cart item not found"));

        cartItem.setQuantity(quantity);
        return cartItemRepo.save(cartItem);
    }

    public void deleteCartItem(int id) {
        if (!cartItemRepo.existsById(id)) {
            throw new EntityNotFoundException("Cart item not found");
        }
        cartItemRepo.deleteById(id);
    }

    public void clearCartForUser(String email) {
        List<CartItem> items = cartItemRepo.findByUserEmail(email);
        cartItemRepo.deleteAll(items);
    }
}
