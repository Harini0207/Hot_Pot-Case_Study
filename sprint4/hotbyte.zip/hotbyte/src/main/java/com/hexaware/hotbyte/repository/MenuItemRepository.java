package com.hexaware.hotbyte.repository;

import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.entity.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer> {

    // Find all menu items of a specific restaurant
    List<MenuItem> findByRestaurant(Restaurant restaurant);

    // Optional: Find only available menu items of a specific restaurant
    List<MenuItem> findByRestaurantAndAvailabilityTrue(Restaurant restaurant);

    // Flexible filter search for menu items
    @Query("SELECT m FROM MenuItem m WHERE " +
           "(:category IS NULL OR m.category = :category) AND " +
           "(:veg IS NULL OR m.veg = :veg) AND " +
           "(:minPrice IS NULL OR m.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR m.price <= :maxPrice) AND " +
           "(:keyword IS NULL OR LOWER(m.name) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<MenuItem> filterMenus(String category, Boolean veg, Double minPrice, Double maxPrice, String keyword);
}
