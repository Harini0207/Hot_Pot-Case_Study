package com.example.hexaware.hotbyte.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.hexaware.hotbyte.entity.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer> {

    @Query("SELECT r FROM Review r WHERE r.menuItem.restaurant.id = :restaurantId")
    List<Review> findByRestaurantId(@Param("restaurantId") int restaurantId);

}
