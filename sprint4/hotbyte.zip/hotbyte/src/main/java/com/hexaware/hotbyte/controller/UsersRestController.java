package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.Users;
import com.hexaware.hotbyte.repository.UsersRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UsersRestController {

    @Autowired
    private UsersRepository usersRepository;

    // GET all users
    @GetMapping
    public List<Users> getAllUsers() {
        return usersRepository.findAll();
    }

    // GET a user by email
    @GetMapping("/{email}")
    public Users getUserByEmail(@PathVariable String email) {
        return usersRepository.findById(email)
                .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));
    }

    // POST: Register a new user
    @PostMapping
    public Users registerUser(@RequestBody Users user) {
        if (usersRepository.existsById(user.getEmail())) {
            throw new RuntimeException("Email already registered.");
        }
        return usersRepository.save(user);
    }

    // POST: Login (simple password check)
    @PostMapping("/login")
    public String login(@RequestBody Users credentials) {
        Users user = usersRepository.findById(credentials.getEmail())
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        if (user.getPassword().equals(credentials.getPassword())) {
            return "Login successful. Role: " + user.getRole();
        } else {
            return "Invalid password";
        }
    }

    // DELETE a user by email
    @DeleteMapping("/{email}")
    public String deleteUser(@PathVariable String email) {
        if (!usersRepository.existsById(email)) {
            return "User not found.";
        }
        usersRepository.deleteById(email);
        return "User deleted successfully.";
    }
}
