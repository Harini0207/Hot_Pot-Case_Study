package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.entity.Category;
import com.example.hexaware.hotbyte.repository.CategoryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class CategoryEntityTest {

    @Autowired
    private CategoryRepository categoryRepository;

    @Test
    void testCategoryGettersSetters() {
        Category category = new Category("Desserts", "Sweet items");
        category.setId(1);
        assertEquals(1, category.getId());
        assertEquals("Desserts", category.getName());
        assertEquals("Sweet items", category.getDescription());

        category.setName("Snacks");
        category.setDescription("Quick bites");

        assertEquals("Snacks", category.getName());
        assertEquals("Quick bites", category.getDescription());
    }

    @Test
    void testCategoryRepositorySaveAndFind() {
        Category category = new Category("Beverages", "Drinks and cold items");
        categoryRepository.save(category);

        Optional<Category> result = categoryRepository.findById(category.getId());
        assertTrue(result.isPresent());
        assertEquals("Beverages", result.get().getName());
        assertEquals("Drinks and cold items", result.get().getDescription());
    }
}
