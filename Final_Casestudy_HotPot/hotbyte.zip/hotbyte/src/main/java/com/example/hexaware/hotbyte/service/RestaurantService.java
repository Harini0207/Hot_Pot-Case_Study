package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.repository.RestaurantRepository;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private UsersRepository usersRepository;

    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    public Restaurant getRestaurantById(int id) {
        return restaurantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + id));
    }

    public Restaurant getRestaurantByEmail(String email) {
        return restaurantRepository.findByOwner_Email(email).orElse(null);
    }

    public Restaurant createRestaurant(Restaurant restaurant) {
        if (restaurant.getOwner() != null &&
            !usersRepository.existsById(restaurant.getOwner().getEmail())) {
            throw new EntityNotFoundException("Owner email not found: " + restaurant.getOwner().getEmail());
        }
        return restaurantRepository.save(restaurant);
    }
    public Restaurant updateRestaurant(int id, Restaurant updatedRestaurant) {
        Restaurant existing = restaurantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + id));

        existing.setName(updatedRestaurant.getName());
        existing.setAddress(updatedRestaurant.getAddress());
        existing.setContactNumber(updatedRestaurant.getContactNumber());
        existing.setEmail(updatedRestaurant.getEmail());
        existing.setImageUrl(updatedRestaurant.getImageUrl());

        // ✅ Preserve existing owner if not provided in request
        if (updatedRestaurant.getOwner() != null) {
            existing.setOwner(updatedRestaurant.getOwner());
        }

        return restaurantRepository.save(existing);
    }

    public void deleteRestaurant(int id) {
        if (!restaurantRepository.existsById(id)) {
            throw new EntityNotFoundException("Restaurant not found with ID: " + id);
        }
        restaurantRepository.deleteById(id);
    }
}
