package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.OrderItem;
import com.hexaware.hotbyte.entity.Orders;
import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.repository.OrderItemRepository;
import com.hexaware.hotbyte.repository.OrdersRepository;
import com.hexaware.hotbyte.repository.MenuItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order-items")
public class OrderItemRestController {

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private OrdersRepository ordersRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    // GET all order items
    @GetMapping
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    // GET a single order item by ID
    @GetMapping("/{id}")
    public OrderItem getOrderItemById(@PathVariable int id) {
        return orderItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order item not found with ID: " + id));
    }

    // POST a new order item
    @PostMapping
    public OrderItem createOrderItem(@RequestBody OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    // PUT update an order item
    @PutMapping("/{id}")
    public OrderItem updateOrderItem(@PathVariable int id, @RequestBody OrderItem updatedItem) {
        OrderItem existingItem = orderItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order item not found with ID: " + id));

        existingItem.setQuantity(updatedItem.getQuantity());
        existingItem.setPrice(updatedItem.getPrice());
        existingItem.setOrder(updatedItem.getOrder());
        existingItem.setMenuItem(updatedItem.getMenuItem());

        return orderItemRepository.save(existingItem);
    }

    // DELETE an order item
    @DeleteMapping("/{id}")
    public String deleteOrderItem(@PathVariable int id) {
        if (!orderItemRepository.existsById(id)) {
            return "Order item not found.";
        }
        orderItemRepository.deleteById(id);
        return "Order item deleted successfully.";
    }
}
