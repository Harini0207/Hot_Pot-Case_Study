package com.example.hexaware.hotbyte.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.entity.Users;

public interface RestaurantRepository extends JpaRepository<Restaurant, Integer> {

    
    Optional<Restaurant> findByOwner_Email(String email);

    Restaurant findByOwner(Users owner);
}
