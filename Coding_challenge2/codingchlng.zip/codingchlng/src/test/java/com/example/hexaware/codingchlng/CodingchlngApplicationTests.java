package com.example.hexaware.codingchlng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingchlngApplicationTests {

	@Test
	void contextLoads() {
	}

}
