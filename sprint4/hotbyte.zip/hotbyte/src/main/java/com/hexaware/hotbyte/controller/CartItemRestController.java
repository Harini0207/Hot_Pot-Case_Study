package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.CartItem;
import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.entity.Users;
import com.hexaware.hotbyte.repository.CartItemRepository;
import com.hexaware.hotbyte.repository.MenuItemRepository;
import com.hexaware.hotbyte.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartItemRestController {

    @Autowired
    private CartItemRepository cartItemRepo;

    @Autowired
    private UsersRepository usersRepo;

    @Autowired
    private MenuItemRepository menuItemRepo;

    // Get all cart items
    @GetMapping
    public List<CartItem> getAllCartItems() {
        return cartItemRepo.findAll();
    }

    // Get cart items for a specific user
    @GetMapping("/user/{email}")
    public List<CartItem> getCartItemsByUser(@PathVariable String email) {
        return cartItemRepo.findByUserEmail(email);
    }

    // Add a cart item
    @PostMapping
    public CartItem addCartItem(@RequestParam String userEmail,
                                @RequestParam int menuItemId,
                                @RequestParam(defaultValue = "1") int quantity) {

        Users user = usersRepo.findById(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        MenuItem menuItem = menuItemRepo.findById(menuItemId)
                .orElseThrow(() -> new RuntimeException("Menu item not found"));

        CartItem cartItem = new CartItem(user, menuItem, quantity);
        return cartItemRepo.save(cartItem);
    }

    // Update cart item quantity
    @PutMapping("/{id}")
    public CartItem updateCartItem(@PathVariable int id, @RequestParam int quantity) {
        CartItem cartItem = cartItemRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        cartItem.setQuantity(quantity);
        return cartItemRepo.save(cartItem);
    }

    // Delete a cart item
    @DeleteMapping("/{id}")
    public String deleteCartItem(@PathVariable int id) {
        if (!cartItemRepo.existsById(id)) {
            return "Cart item not found.";
        }
        cartItemRepo.deleteById(id);
        return "Cart item deleted successfully.";
    }

    // Clear cart for a user
    @DeleteMapping("/user/{email}")
    public String clearUserCart(@PathVariable String email) {
        List<CartItem> items = cartItemRepo.findByUserEmail(email);
        cartItemRepo.deleteAll(items);
        return "Cart cleared for user: " + email;
    }
}
