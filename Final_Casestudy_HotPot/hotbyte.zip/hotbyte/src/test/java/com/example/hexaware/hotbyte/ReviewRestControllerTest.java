package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.ReviewRestController;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Review;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.ReviewService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReviewRestController.class)
@AutoConfigureMockMvc(addFilters = false)
class ReviewRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReviewService reviewService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser
    void testGetAllReviews() throws Exception {
        Users user = new Users("user1@example.com", "pass", "User One", "1234567890", "Address", "Male");
        MenuItem item = new MenuItem();
        item.setId(1);
        item.setName("Pizza");

        Review review = new Review(user, item, 5, "Delicious!");

        Mockito.when(reviewService.getAllReviews()).thenReturn(List.of(review));

        mockMvc.perform(get("/api/reviews"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].comment").value("Delicious!"));
    }

    @Test
    @WithMockUser
    void testGetReviewById() throws Exception {
        Users user = new Users("user1@example.com", "pass", "User One", "1234567890", "Address", "Male");
        MenuItem item = new MenuItem();
        item.setId(1);
        item.setName("Burger");

        Review review = new Review(user, item, 4, "Nice taste");

        Mockito.when(reviewService.getReviewById(1)).thenReturn(review);

        mockMvc.perform(get("/api/reviews/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.comment").value("Nice taste"));
    }

    @Test
    @WithMockUser
    void testCreateReview() throws Exception {
        Users user = new Users("user2@example.com", "pass", "User Two", "0987654321", "Address", "Female");
        MenuItem item = new MenuItem();
        item.setId(2);
        item.setName("Pasta");

        Review review = new Review(user, item, 3, "Okayish");
        review.setId(100);

        Mockito.when(reviewService.createReview(any(Review.class))).thenReturn(review);

        mockMvc.perform(post("/api/reviews")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(review)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rating").value(3))
                .andExpect(jsonPath("$.comment").value("Okayish"));
    }

    @Test
    @WithMockUser
    void testDeleteReview() throws Exception {
        mockMvc.perform(delete("/api/reviews/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Review deleted successfully"));
    }

    @Test
    @WithMockUser
    void testGetReviewsByRestaurantId() throws Exception {
        Users user = new Users("user@example.com", "pass", "Test User", "1112223333", "Somewhere", "Male");
        MenuItem item = new MenuItem();
        item.setId(10);
        item.setName("Sandwich");

        Review review = new Review(user, item, 5, "Excellent!");

        Mockito.when(reviewService.getReviewsByRestaurantId(5)).thenReturn(List.of(review));

        mockMvc.perform(get("/api/reviews/restaurant/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].comment").value("Excellent!"));
    }
}
