package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.exception.UserAlreadyExistsException;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UsersRepository usersRepository;

    public List<Users> getAllUsers() {
        return usersRepository.findAll();
    }

    public Users getUserByEmail(String email) {
        return usersRepository.findById(email)
                .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));
    }

    public Users registerUser(Users user) {
        if (usersRepository.existsById(user.getEmail())) {
            throw new UserAlreadyExistsException("Email already registered.");
        }
        return usersRepository.save(user);
    }

    public String loginUser(Users credentials) {
        Users user = usersRepository.findById(credentials.getEmail())
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        if (user.getPassword().equals(credentials.getPassword())) {
            return "Login successful. Role: " + user.getRole();
        } else {
            return "Invalid password";
        }
    }

    public String deleteUser(String email) {
        if (!usersRepository.existsById(email)) {
            throw new EntityNotFoundException("User not found.");
        }
        usersRepository.deleteById(email);
        return "User deleted successfully.";
    }

    public Users updateUser(String email, Users updatedUser) {
        Users existingUser = usersRepository.findById(email)
            .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));

        existingUser.setName(updatedUser.getName());
        existingUser.setPhone(updatedUser.getPhone());
        existingUser.setAddress(updatedUser.getAddress());
        existingUser.setGender(updatedUser.getGender());
        existingUser.setRole(updatedUser.getRole());

        // ✅ Only set password if present
        if (updatedUser.getPassword() != null && !updatedUser.getPassword().trim().isEmpty()) {
            existingUser.setPassword(updatedUser.getPassword());
        }

        return usersRepository.save(existingUser);
    }

}
