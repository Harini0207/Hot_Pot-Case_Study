package com.hexaware.hotbyte.repository;

import com.hexaware.hotbyte.entity.Orders;
import com.hexaware.hotbyte.entity.Restaurant;
import com.hexaware.hotbyte.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrdersRepository extends JpaRepository<Orders, Integer> {
    List<Orders> findByUser(Users user);
    List<Orders> findByRestaurant(Restaurant restaurant);
}
