package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.OrderItem;
import com.example.hexaware.hotbyte.repository.OrderItemRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderItemService {

    @Autowired
    private OrderItemRepository orderItemRepository;

    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    public OrderItem getOrderItemById(int id) {
        return orderItemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Order item not found with ID: " + id));
    }

    public OrderItem createOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    public OrderItem updateOrderItem(int id, OrderItem updatedItem) {
        OrderItem existingItem = getOrderItemById(id);
        existingItem.setQuantity(updatedItem.getQuantity());
        existingItem.setPrice(updatedItem.getPrice());
        existingItem.setOrder(updatedItem.getOrder());
        existingItem.setMenuItem(updatedItem.getMenuItem());
        return orderItemRepository.save(existingItem);
    }

    public void deleteOrderItem(int id) {
        if (!orderItemRepository.existsById(id)) {
            throw new EntityNotFoundException("Order item not found.");
        }
        orderItemRepository.deleteById(id);
    }
}
