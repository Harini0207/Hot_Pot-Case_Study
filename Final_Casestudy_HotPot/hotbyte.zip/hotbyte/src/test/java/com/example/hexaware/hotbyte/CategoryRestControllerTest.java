package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.CategoryRestController;
import com.example.hexaware.hotbyte.entity.Category;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.CategoryService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CategoryRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class CategoryRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CategoryService categoryService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testGetAllCategories() throws Exception {
        Category c1 = new Category("Starter", "Starter dishes");
        c1.setId(1);
        Mockito.when(categoryService.getAllCategories()).thenReturn(List.of(c1));

        mockMvc.perform(get("/api/categories"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Starter"));
    }

    @Test
    void testGetCategoryById() throws Exception {
        Category category = new Category("Desserts", "Sweet dishes");
        category.setId(2);

        Mockito.when(categoryService.getCategoryById(2)).thenReturn(category);

        mockMvc.perform(get("/api/categories/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Desserts"));
    }

    @Test
    void testCreateCategory() throws Exception {
        Category input = new Category("Snacks", "Quick bites");
        Category saved = new Category("Snacks", "Quick bites");
        saved.setId(3);

        Mockito.when(categoryService.createCategory(any(Category.class))).thenReturn(saved);

        mockMvc.perform(post("/api/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.name").value("Snacks"));
    }

    @Test
    void testUpdateCategory() throws Exception {
        Category updated = new Category("Main Course", "Hearty meals");
        updated.setId(4);

        Mockito.when(categoryService.updateCategory(eq(4), any(Category.class))).thenReturn(updated);

        mockMvc.perform(put("/api/categories/4")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Main Course"));
    }

    @Test
    void testDeleteCategory() throws Exception {
        Mockito.doNothing().when(categoryService).deleteCategory(5);

        mockMvc.perform(delete("/api/categories/5"))
                .andExpect(status().isOk())
                .andExpect(content().string("Category deleted successfully."));
    }
}
