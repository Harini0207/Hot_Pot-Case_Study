package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.OrdersRestController;
import com.example.hexaware.hotbyte.entity.*;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.OrdersService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrdersRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class OrdersRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrdersService ordersService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(roles = "USER")
    void testPlaceOrder() throws Exception {
        Users user = new Users("test@example.com", "pass", "User", "9999999999", "Address", "Male");
        MenuItem item = new MenuItem();
        item.setId(1);
        item.setName("Pizza");
        item.setPrice(BigDecimal.valueOf(200));

        OrderItem orderItem = new OrderItem();
        orderItem.setMenuItem(item);
        orderItem.setQuantity(2);

        Orders incoming = new Orders();
        incoming.setUser(user);
        incoming.setShippingAddress("123 Street");
        incoming.setPaymentMethod("UPI");
        incoming.setOrderItems(List.of(orderItem));

        Orders savedOrder = new Orders();
        savedOrder.setId(1);
        savedOrder.setUser(user);
        savedOrder.setShippingAddress("123 Street");
        savedOrder.setPaymentMethod("UPI");
        savedOrder.setOrderItems(List.of(orderItem));
        savedOrder.setTotalAmount(BigDecimal.valueOf(400));

        Mockito.when(ordersService.placeOrder(any(Orders.class))).thenReturn(savedOrder);

        mockMvc.perform(post("/api/orders/place")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(incoming)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.totalAmount").value(400));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testGetAllOrders() throws Exception {
        Orders order = new Orders();
        order.setId(1);
        order.setStatus("Placed");
        order.setTotalAmount(BigDecimal.valueOf(300));

        Mockito.when(ordersService.getAllOrders()).thenReturn(List.of(order));

        mockMvc.perform(get("/api/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testGetOrderById() throws Exception {
        Orders order = new Orders();
        order.setId(2);
        order.setStatus("Placed");
        order.setTotalAmount(BigDecimal.valueOf(500));

        Mockito.when(ordersService.getOrderById(2)).thenReturn(Optional.of(order));

        mockMvc.perform(get("/api/orders/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(2));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testDeleteOrder() throws Exception {
        Mockito.doNothing().when(ordersService).deleteOrder(5);

        mockMvc.perform(delete("/api/orders/5"))
                .andExpect(status().isOk())
                .andExpect(content().string("Order deleted successfully"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testUpdateOrder() throws Exception {
        Orders updated = new Orders();
        updated.setShippingAddress("New Address");
        updated.setPaymentMethod("Card");
        updated.setStatus("Shipped");

        Orders saved = new Orders();
        saved.setId(10);
        saved.setShippingAddress("New Address");
        saved.setPaymentMethod("Card");
        saved.setStatus("Shipped");

        Mockito.when(ordersService.updateOrder(eq(10), any(Orders.class))).thenReturn(saved);

        mockMvc.perform(put("/api/orders/10")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("Shipped"))
                .andExpect(jsonPath("$.paymentMethod").value("Card"));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testCancelOrderWithinTime() throws Exception {
        Mockito.when(ordersService.cancelOrder(3)).thenReturn(true);

        mockMvc.perform(put("/api/orders/3/cancel"))
                .andExpect(status().isOk())
                .andExpect(content().string("Order cancelled successfully."));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testCancelOrderTooLate() throws Exception {
        Mockito.when(ordersService.cancelOrder(4)).thenReturn(false);

        mockMvc.perform(put("/api/orders/4/cancel"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("❌ Order cannot be cancelled after 15 minutes or it's already cancelled."));
    }
}
