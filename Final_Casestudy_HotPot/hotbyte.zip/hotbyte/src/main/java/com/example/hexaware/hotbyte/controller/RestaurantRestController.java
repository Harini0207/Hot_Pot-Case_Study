package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.service.RestaurantService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/restaurants")
@CrossOrigin(origins = "*")
public class RestaurantRestController {

    @Autowired
    private RestaurantService restaurantService;

    @PreAuthorize("hasAnyRole('USER', 'ADMIN', 'RESTAURANT')")
    @GetMapping
    public List<Restaurant> getAllRestaurants() {
        return restaurantService.getAllRestaurants();
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN', 'RESTAURANT')")
    @GetMapping("/{id}")
    public Restaurant getRestaurantById(@PathVariable int id) {
        return restaurantService.getRestaurantById(id);
    }

    @PreAuthorize("hasAnyRole('USER', 'ADMIN', 'RESTAURANT')")
    @GetMapping("/byEmail/{email}")
    public ResponseEntity<Restaurant> getRestaurantByEmail(@PathVariable String email) {
        Restaurant restaurant = restaurantService.getRestaurantByEmail(email);
        if (restaurant != null) {
            return ResponseEntity.ok(restaurant);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public Restaurant createRestaurant(@Valid @RequestBody Restaurant restaurant) {
        return restaurantService.createRestaurant(restaurant);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Restaurant updateRestaurant(@PathVariable int id, @RequestBody Restaurant updatedRestaurant) {
        return restaurantService.updateRestaurant(id, updatedRestaurant);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteRestaurant(@PathVariable int id) {
        restaurantService.deleteRestaurant(id);
        return "Restaurant deleted successfully.";
    }
}
