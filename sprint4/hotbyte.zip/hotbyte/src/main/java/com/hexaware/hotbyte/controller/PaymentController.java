package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.Payment;
import com.hexaware.hotbyte.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepository;

    // View all payments
    @GetMapping
    public String viewAllPayments(Model model) {
        List<Payment> payments = paymentRepository.findAll();
        model.addAttribute("payments", payments);
        return "payment-list"; // ➤ JSP file (payment-list.jsp)
    }

    // Show form to add new payment
    @GetMapping("/new")
    public String showPaymentForm(Model model) {
        model.addAttribute("payment", new Payment());
        return "payment-form"; // ➤ JSP file (payment-form.jsp)
    }

    // Save payment
    @PostMapping("/save")
    public String savePayment(@ModelAttribute("payment") Payment payment) {
        paymentRepository.save(payment);
        return "redirect:/payments";
    }

    // Edit payment
    @GetMapping("/edit/{id}")
    public String editPayment(@PathVariable int id, Model model) {
        Payment payment = paymentRepository.findById(id).orElse(null);
        if (payment != null) {
            model.addAttribute("payment", payment);
            return "payment-form";
        } else {
            return "redirect:/payments";
        }
    }

    // Delete payment
    @GetMapping("/delete/{id}")
    public String deletePayment(@PathVariable int id) {
        paymentRepository.deleteById(id);
        return "redirect:/payments";
    }
}
