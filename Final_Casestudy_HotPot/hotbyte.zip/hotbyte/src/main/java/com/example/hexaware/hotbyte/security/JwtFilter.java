package com.example.hexaware.hotbyte.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        final String header = request.getHeader("Authorization");

        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            try {
                if (jwtUtils.validateToken(token)) {
                    String email = jwtUtils.extractEmail(token);
                    String role = jwtUtils.extractRole(token).toUpperCase();
                    String authorityString = "ROLE_" + role;

                    System.out.println("✅ JWT Token Validated");
                    System.out.println("Email: " + email);
                    System.out.println("Role: " + role);
                    System.out.println("Authority: " + authorityString);
                    

                    SimpleGrantedAuthority authority = new SimpleGrantedAuthority(authorityString);
                    User userDetails = new User(email, "", Collections.singletonList(authority));

                    UsernamePasswordAuthenticationToken authenticationToken =
                            new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                    authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authenticationToken);
                } else {
                    System.out.println("❌ Invalid JWT token received");
                }
            } catch (Exception e) {
                System.out.println("❌ Error parsing JWT token: " + e.getMessage());
            }
        } else {
            System.out.println("❗ No Authorization header found or doesn't start with Bearer");
        }

        filterChain.doFilter(request, response);
    }
}
