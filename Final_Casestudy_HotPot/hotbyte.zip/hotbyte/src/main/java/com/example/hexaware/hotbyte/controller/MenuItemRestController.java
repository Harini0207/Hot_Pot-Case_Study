package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.service.MenuItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/menu-items")
@CrossOrigin(origins = "*")
public class MenuItemRestController {

    @Autowired
    private MenuItemService menuItemService;

    // ✅ Get all menu items
    @GetMapping
    public List<MenuItem> getAllMenuItems() {
        return menuItemService.getAllMenuItems();
    }

    // ✅ Get menu item by ID
    @GetMapping("/{id}")
    public MenuItem getMenuItemById(@PathVariable int id) {
        return menuItemService.getMenuItemById(id);
    }

    // ✅ Get menu items by restaurant ID
    @GetMapping("/restaurant/{restaurantId}")
    public List<MenuItem> getMenuItemsByRestaurantId(@PathVariable int restaurantId) {
        return menuItemService.getMenuItemsByRestaurantId(restaurantId);
    }

    // ✅ Filter menu items
    @GetMapping("/filter")
    public List<MenuItem> filterMenuItems(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String dietType,
            @RequestParam(required = false) String priceRange,
            @RequestParam(required = false) String keyword
    ) {
        return menuItemService.filterMenuItems(category, dietType, priceRange, keyword);
    }

    // ✅ Create new menu item
    @PostMapping
    public MenuItem createMenuItem(@RequestBody MenuItem menuItem) {
        return menuItemService.createMenuItem(menuItem);
    }

    // ✅ Update menu item (accept raw map to avoid JSON parsing issues)
    @PutMapping("/{id}")
    public MenuItem updateMenuItem(@PathVariable int id, @RequestBody Map<String, Object> payload) {
        return menuItemService.updateMenuItem(id, payload);
    }

    // ✅ Delete menu item
    @DeleteMapping("/{id}")
    public String deleteMenuItem(@PathVariable int id) {
        menuItemService.deleteMenuItem(id);
        return "Menu item deleted successfully.";
    }
}
