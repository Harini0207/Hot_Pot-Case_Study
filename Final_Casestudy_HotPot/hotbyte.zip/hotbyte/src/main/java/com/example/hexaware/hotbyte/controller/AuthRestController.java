package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.repository.UsersRepository;
import com.example.hexaware.hotbyte.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000") // ✅ Adjust if needed
public class AuthRestController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Users user) {
        Map<String, Object> response = new HashMap<>();
        Users existing = usersRepository.findById(user.getEmail()).orElse(null);

        if (existing != null && existing.getPassword().equals(user.getPassword())) {
            String token = jwtUtils.generateToken(existing.getEmail(), existing.getRole());

            response.put("token", token);
            response.put("email", existing.getEmail());
            response.put("role", existing.getRole());
            response.put("name", existing.getName());

            // ✅ If user is a restaurant owner, return their first restaurant
            if ("RESTAURANT".equalsIgnoreCase(existing.getRole())) {
                List<Restaurant> ownedRestaurants = existing.getRestaurants();
                if (ownedRestaurants != null && !ownedRestaurants.isEmpty()) {
                    response.put("restaurant", ownedRestaurants.get(0));
                }
            }

            System.out.println("✅ Login successful for: " + existing.getEmail());
        } else {
            response.put("error", "Invalid email or password");
            System.out.println("❌ Login failed for: " + user.getEmail());
        }

        return response;
    }

    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody Users user) {
        Map<String, Object> response = new HashMap<>();
        if (usersRepository.existsById(user.getEmail())) {
            response.put("error", "Email already exists");
        } else {
            usersRepository.save(user);
            response.put("message", "Registration successful");
        }
        return response;
    }
}
