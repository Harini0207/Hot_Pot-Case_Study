package com.hexaware.hotbyte.repository;

import com.hexaware.hotbyte.entity.CartItem;
import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.entity.Users;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem, Integer> {

	List<CartItem> findByUser(Users user); 
    List<CartItem> findByUserEmail(String email);
    CartItem findByUserAndMenuItem(Users user, MenuItem menu);
}
