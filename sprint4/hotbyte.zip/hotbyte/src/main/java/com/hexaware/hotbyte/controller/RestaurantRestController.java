package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.Restaurant;
import com.hexaware.hotbyte.repository.RestaurantRepository;
import com.hexaware.hotbyte.repository.UsersRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/restaurants")
public class RestaurantRestController {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private UsersRepository usersRepository;

    // GET all restaurants
    @GetMapping
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    // GET a restaurant by ID
    @GetMapping("/{id}")
    public Restaurant getRestaurantById(@PathVariable int id) {
        return restaurantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + id));
    }

    // POST: Add a new restaurant
    @PostMapping
    public Restaurant createRestaurant(@RequestBody Restaurant restaurant) {
        // Optional: Validate owner exists
        if (restaurant.getOwner() != null && !usersRepository.existsById(restaurant.getOwner().getEmail())) {
            throw new EntityNotFoundException("Owner email not found: " + restaurant.getOwner().getEmail());
        }
        return restaurantRepository.save(restaurant);
    }

    // PUT: Update an existing restaurant
    @PutMapping("/{id}")
    public Restaurant updateRestaurant(@PathVariable int id, @RequestBody Restaurant updatedRestaurant) {
        Restaurant existing = restaurantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + id));

        existing.setName(updatedRestaurant.getName());
        existing.setAddress(updatedRestaurant.getAddress());
        existing.setContactNumber(updatedRestaurant.getContactNumber());
        existing.setEmail(updatedRestaurant.getEmail());
        existing.setImageUrl(updatedRestaurant.getImageUrl());
        existing.setOwner(updatedRestaurant.getOwner());

        return restaurantRepository.save(existing);
    }

    // DELETE a restaurant by ID
    @DeleteMapping("/{id}")
    public String deleteRestaurant(@PathVariable int id) {
        if (!restaurantRepository.existsById(id)) {
            return "Restaurant not found.";
        }
        restaurantRepository.deleteById(id);
        return "Restaurant deleted successfully.";
    }
}
