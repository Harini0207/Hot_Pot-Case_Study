package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.*;
import com.hexaware.hotbyte.repository.*;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
public class MyController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private OrdersRepository ordersRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @RequestMapping("/")
    public String index() {
        return "index";
    }

    @RequestMapping("/registerPage")
    public String registerPage() {
        return "register";
    }

    @RequestMapping("/loginPage")
    public String loginPage(@ModelAttribute("msg") String msg, Model model) {
        model.addAttribute("msg", msg);
        return "login";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute Users user, RedirectAttributes attributes) {
        if (usersRepository.existsById(user.getEmail())) {
            attributes.addFlashAttribute("msg", "Email already registered.");
            return "redirect:/registerPage";
        }
        usersRepository.save(user);
        attributes.addFlashAttribute("msg", "Registration successful! Please log in.");
        return "redirect:/loginPage";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute Users users, HttpSession session, RedirectAttributes attributes) {
        try {
            Users user = usersRepository.getReferenceById(users.getEmail());
            if (user.getPassword().equals(users.getPassword())) {
                session.setAttribute("currentUser", user);
                String role = user.getRole().toLowerCase();
                if (role.equals("admin")) return "redirect:/adminhome";
                if (role.equals("restaurant")) return "redirect:/restauranthome";
                return "redirect:/userhome";
            } else {
                attributes.addFlashAttribute("msg", "Invalid password.");
                return "redirect:/loginPage";
            }
        } catch (EntityNotFoundException e) {
            attributes.addFlashAttribute("msg", "Invalid email or user does not exist.");
            return "redirect:/loginPage";
        }
    }

    @GetMapping("/userhome")
    public String userHome(HttpSession session, Model model) {
        Users currentUser = (Users) session.getAttribute("currentUser");
        if (currentUser == null || currentUser.getEmail() == null) {
            return "redirect:/loginPage";
        }
        Users user = usersRepository.getReferenceById(currentUser.getEmail());
        model.addAttribute("currentUser", user);
        model.addAttribute("menus", menuItemRepository.findAll());
        return "userhome";
    }

    @GetMapping("/filterMenu")
    public String filterMenu(@RequestParam(required = false) String category,
                             @RequestParam(required = false) String dietType,
                             @RequestParam(required = false) String priceRange,
                             @RequestParam(required = false) String keyword,
                             HttpSession session, Model model) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        Double minPrice = null, maxPrice = null;

        if (priceRange != null && !priceRange.isEmpty()) {
            switch (priceRange) {
                case "0-100" -> {
                    minPrice = 0.0;
                    maxPrice = 100.0;
                }
                case "100-200" -> {
                    minPrice = 100.0;
                    maxPrice = 200.0;
                }
                case "200-500" -> {
                    minPrice = 200.0;
                    maxPrice = 500.0;
                }
                case "500-1000" -> {
                    minPrice = 500.0;
                    maxPrice = 1000.0;
                }
            }
        }

        Boolean veg = null;
        if (dietType != null && !dietType.isEmpty()) {
            veg = dietType.equalsIgnoreCase("veg");
        }

        List<MenuItem> filteredMenus = menuItemRepository.filterMenus(
                (category != null && !category.isEmpty()) ? category : null,
                veg, minPrice, maxPrice,
                (keyword != null && !keyword.isEmpty()) ? keyword : null
        );

        model.addAttribute("menus", filteredMenus);
        model.addAttribute("currentUser", user);
        return "userhome";
    }

    @GetMapping("/viewMenuItem")
    public String viewMenuDetails(@RequestParam int id, HttpSession session, Model model) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        MenuItem menu = menuItemRepository.findById(id).orElse(null);
        if (menu == null) return "redirect:/userhome";

        model.addAttribute("menu", menu);
        model.addAttribute("currentUser", user);
        return "menuDetail";
    }

    @PostMapping("/addToCart")
    public String addToCart(@RequestParam("menuId") int menuId, HttpSession session) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        MenuItem menu = menuItemRepository.findById(menuId).orElse(null);
        if (menu == null) return "redirect:/userhome";

        CartItem existing = cartItemRepository.findByUserAndMenuItem(user, menu);
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + 1);
            cartItemRepository.save(existing);
        } else {
            CartItem item = new CartItem();
            item.setUser(user);
            item.setMenuItem(menu);
            item.setQuantity(1);
            cartItemRepository.save(item);
        }

        return "redirect:/viewCart";
    }

    @GetMapping("/viewCart")
    public String viewCart(HttpSession session, Model model) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        List<CartItem> cartItems = cartItemRepository.findByUser(user);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("currentUser", user);
        return "cart";
    }

    @PostMapping("/updateCart")
    public String updateCart(@RequestParam Map<String, String> quantities, HttpSession session) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        for (Map.Entry<String, String> entry : quantities.entrySet()) {
            int itemId = Integer.parseInt(entry.getKey().replace("quantities[", "").replace("]", ""));
            int quantity = Integer.parseInt(entry.getValue());

            CartItem item = cartItemRepository.findById(itemId).orElse(null);
            if (item != null && item.getUser().getEmail().equals(user.getEmail())) {
                item.setQuantity(quantity);
                cartItemRepository.save(item);
            }
        }

        return "redirect:/viewCart";
    }

    @PostMapping("/removeCartItem")
    public String removeCartItem(@RequestParam("cartItemId") int cartItemId, HttpSession session) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        CartItem item = cartItemRepository.findById(cartItemId).orElse(null);
        if (item != null && item.getUser().getEmail().equals(user.getEmail())) {
            cartItemRepository.delete(item);
        }

        return "redirect:/viewCart";
    }

    @PostMapping("/placeOrder")
    public String placeOrder(@RequestParam("shippingAddress") String address,
                             @RequestParam("paymentMethod") String paymentMethod,
                             HttpSession session,
                             RedirectAttributes attributes) {
        Users user = (Users) session.getAttribute("currentUser");
        if (user == null) return "redirect:/loginPage";

        List<CartItem> cartItems = cartItemRepository.findByUser(user);
        if (cartItems.isEmpty()) {
            attributes.addFlashAttribute("msg", "Your cart is empty.");
            return "redirect:/viewCart";
        }

        BigDecimal total = BigDecimal.ZERO;
        Restaurant restaurant = cartItems.get(0).getMenuItem().getRestaurant();

        Orders order = new Orders();
        order.setUser(user);
        order.setRestaurant(restaurant);
        order.setStatus("Placed");
        order.setOrderDate(java.time.LocalDateTime.now());
        ordersRepository.save(order);

        for (CartItem cart : cartItems) {
            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setMenuItem(cart.getMenuItem());
            item.setQuantity(cart.getQuantity());
            BigDecimal itemTotal = cart.getMenuItem().getPrice().multiply(BigDecimal.valueOf(cart.getQuantity()));
            item.setPrice(itemTotal);
            orderItemRepository.save(item);
            total = total.add(itemTotal);
        }

        order.setTotalAmount(total);
        ordersRepository.save(order);
        cartItemRepository.deleteAll(cartItems);
        attributes.addFlashAttribute("msg", "Order placed successfully!");
        return "redirect:/viewOrders";
    }

    @GetMapping("/viewOrders")
    public String viewOrders(HttpSession session, Model model) {
        Users currentUser = (Users) session.getAttribute("currentUser");
        if (currentUser == null) return "redirect:/loginPage";

        List<Orders> orders;
        switch (currentUser.getRole().toLowerCase()) {
            case "admin" -> orders = ordersRepository.findAll();
            case "restaurant" -> {
                Restaurant restaurant = restaurantRepository.findByOwner(currentUser);
                orders = ordersRepository.findByRestaurant(restaurant);
            }
            default -> orders = ordersRepository.findByUser(currentUser);
        }

        model.addAttribute("orders", orders);
        model.addAttribute("currentUser", currentUser);
        return "orders";
    }

    @PostMapping("/updateOrderStatus")
    public String updateOrderStatus(@RequestParam int orderId,
                                    @RequestParam String status,
                                    HttpSession session) {
        Users currentUser = (Users) session.getAttribute("currentUser");
        if (currentUser == null || !currentUser.getRole().equalsIgnoreCase("restaurant")) {
            return "redirect:/loginPage";
        }

        Orders order = ordersRepository.findById(orderId).orElse(null);
        if (order != null) {
            order.setStatus(status);
            ordersRepository.save(order);
        }

        return "redirect:/viewOrders";
    }

    @GetMapping("/restauranthome")
    public String restaurantHome(HttpSession session, Model model) {
        Users currentUser = (Users) session.getAttribute("currentUser");
        if (currentUser == null || !currentUser.getRole().equalsIgnoreCase("restaurant")) {
            return "redirect:/loginPage";
        }

        Restaurant restaurant = restaurantRepository.findByOwner(currentUser);
        List<MenuItem> menuItems = menuItemRepository.findByRestaurant(restaurant);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("restaurant", restaurant);
        model.addAttribute("menus", menuItems);
        return "restauranthome";
    }

    @GetMapping("/adminhome")
    public String adminHome(HttpSession session, Model model) {
        Users currentUser = (Users) session.getAttribute("currentUser");
        if (currentUser == null || !currentUser.getRole().equalsIgnoreCase("admin")) {
            return "redirect:/loginPage";
        }
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("users", usersRepository.findAll());
        model.addAttribute("restaurants", restaurantRepository.findAll());
        return "adminhome";
    }

    @PostMapping("/admin/addUser")
    public String addUser(@ModelAttribute Users newUser, RedirectAttributes redirectAttributes) {
        if (usersRepository.existsById(newUser.getEmail())) {
            redirectAttributes.addFlashAttribute("msg", "User already exists.");
        } else {
            usersRepository.save(newUser);
            redirectAttributes.addFlashAttribute("msg", "User added successfully.");
        }
        return "redirect:/adminhome";
    }

    @PostMapping("/admin/deleteUser")
    public String deleteUser(@RequestParam String email, RedirectAttributes redirectAttributes) {
        if (usersRepository.existsById(email)) {
            usersRepository.deleteById(email);
            redirectAttributes.addFlashAttribute("msg", "User deleted.");
        } else {
            redirectAttributes.addFlashAttribute("msg", "User not found.");
        }
        return "redirect:/adminhome";
    }

    @PostMapping("/admin/addRestaurant")
    public String addRestaurant(@RequestParam String name,
                                @RequestParam String address,
                                @RequestParam String contactNumber,
                                @RequestParam String email,
                                @RequestParam(required = false) String imageUrl,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        if (restaurantRepository.existsByEmail(email)) {
            redirectAttributes.addFlashAttribute("msg", "Restaurant with email already exists.");
            return "redirect:/adminhome";
        }

        Restaurant restaurant = new Restaurant();
        restaurant.setName(name);
        restaurant.setAddress(address);
        restaurant.setContactNumber(contactNumber);
        restaurant.setEmail(email);
        restaurant.setImageUrl(imageUrl);

        if (usersRepository.existsById(email)) {
            Users owner = usersRepository.getReferenceById(email);
            restaurant.setOwner(owner);
        }

        restaurantRepository.save(restaurant);
        redirectAttributes.addFlashAttribute("msg", "Restaurant added successfully.");
        return "redirect:/adminhome";
    }

    @PostMapping("/admin/deleteRestaurant")
    public String deleteRestaurant(@RequestParam int id, RedirectAttributes redirectAttributes) {
        if (restaurantRepository.existsById(id)) {
            restaurantRepository.deleteById(id);
            redirectAttributes.addFlashAttribute("msg", "Restaurant deleted.");
        } else {
            redirectAttributes.addFlashAttribute("msg", "Restaurant not found.");
        }
        return "redirect:/adminhome";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes attributes) {
        session.invalidate();
        attributes.addFlashAttribute("msg", "Logged out successfully.");
        return "redirect:/loginPage";
    }
}
