package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Review;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.repository.MenuItemRepository;
import com.example.hexaware.hotbyte.repository.ReviewRepository;
import com.example.hexaware.hotbyte.repository.UsersRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    public Review getReviewById(int id) {
        return reviewRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Review not found with ID: " + id));
    }

    public Review createReview(@Valid Review incomingReview) {
        String email = incomingReview.getUser().getEmail();
        int menuItemId = incomingReview.getMenuItem().getId();

        Users user = usersRepository.findById(email)
                .orElseThrow(() -> new EntityNotFoundException("User not found with email: " + email));
        MenuItem menuItem = menuItemRepository.findById(menuItemId)
                .orElseThrow(() -> new EntityNotFoundException("Menu item not found with ID: " + menuItemId));

        incomingReview.setUser(user);
        incomingReview.setMenuItem(menuItem);

        return reviewRepository.save(incomingReview);
    }

    public void deleteReview(int id) {
        if (!reviewRepository.existsById(id)) {
            throw new EntityNotFoundException("Review not found.");
        }
        reviewRepository.deleteById(id);
    }
    public List<Review> getReviewsByRestaurantId(int restaurantId) {
        return reviewRepository.findByRestaurantId(restaurantId);
    }

}
