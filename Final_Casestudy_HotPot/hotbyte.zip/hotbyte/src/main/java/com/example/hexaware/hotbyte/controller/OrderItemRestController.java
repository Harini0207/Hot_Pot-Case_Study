package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.OrderItem;
import com.example.hexaware.hotbyte.service.OrderItemService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order-items")
public class OrderItemRestController {

    @Autowired
    private OrderItemService orderItemService;

    @GetMapping
    public List<OrderItem> getAllOrderItems() {
        return orderItemService.getAllOrderItems();
    }

    @GetMapping("/{id}")
    public OrderItem getOrderItemById(@PathVariable int id) {
        return orderItemService.getOrderItemById(id);
    }

    @PostMapping
    public OrderItem createOrderItem(@Valid @RequestBody OrderItem orderItem) {
        return orderItemService.createOrderItem(orderItem);
    }

    @PutMapping("/{id}")
    public OrderItem updateOrderItem(@PathVariable int id, @RequestBody OrderItem updatedItem) {
        return orderItemService.updateOrderItem(id, updatedItem);
    }

    @DeleteMapping("/{id}")
    public String deleteOrderItem(@PathVariable int id) {
        orderItemService.deleteOrderItem(id);
        return "Order item deleted successfully.";
    }
}
