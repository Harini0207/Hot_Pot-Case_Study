package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.Review;
import com.hexaware.hotbyte.entity.Users;
import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.repository.ReviewRepository;
import com.hexaware.hotbyte.repository.UsersRepository;
import com.hexaware.hotbyte.repository.MenuItemRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewRestController {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @GetMapping
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    @PostMapping
    public Review createReview(@RequestBody Review incomingReview) {
        // Fetch user and menuItem from DB
        String email = incomingReview.getUser().getEmail();
        int menuId = incomingReview.getMenuItem().getId();

        Users user = usersRepository.findById(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        MenuItem menuItem = menuItemRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("MenuItem not found with id: " + menuId));

        // Attach to review
        incomingReview.setUser(user);
        incomingReview.setMenuItem(menuItem);

        return reviewRepository.save(incomingReview);
    }

    @GetMapping("/{id}")
    public Review getReviewById(@PathVariable int id) {
        return reviewRepository.findById(id).orElseThrow(() -> new RuntimeException("Review not found"));
    }

    @DeleteMapping("/{id}")
    public String deleteReview(@PathVariable int id) {
        reviewRepository.deleteById(id);
        return "Review deleted successfully";
    }
}
