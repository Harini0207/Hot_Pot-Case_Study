package com.hexaware.hotbyte.repository;

import com.hexaware.hotbyte.entity.Restaurant;
import com.hexaware.hotbyte.entity.Users;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RestaurantRepository extends JpaRepository<Restaurant, Integer> {

    boolean existsByEmail(String email); 
    
    Restaurant findByOwner(Users owner);
}
