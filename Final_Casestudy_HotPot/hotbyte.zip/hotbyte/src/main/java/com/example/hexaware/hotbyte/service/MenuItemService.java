package com.example.hexaware.hotbyte.service;

import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.repository.MenuItemRepository;
import com.example.hexaware.hotbyte.repository.RestaurantRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MenuItemService {

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    // ✅ Get all menu items
    public List<MenuItem> getAllMenuItems() {
        return menuItemRepository.findAll();
    }

    // ✅ Get menu item by ID
    public MenuItem getMenuItemById(int id) {
        return menuItemRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Menu item not found with ID: " + id));
    }

    // ✅ Create menu item
    public MenuItem createMenuItem(MenuItem menuItem) {
        if (menuItem.getRestaurant() == null || menuItem.getRestaurant().getId() == 0) {
            throw new IllegalArgumentException("Restaurant ID is required.");
        }

        Restaurant restaurant = restaurantRepository.findById(menuItem.getRestaurant().getId())
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + menuItem.getRestaurant().getId()));

        menuItem.setRestaurant(restaurant);
        return menuItemRepository.save(menuItem);
    }

    // ✅ Update menu item with validation from raw payload (Map)
    public MenuItem updateMenuItem(int id, Map<String, Object> payload) {
        MenuItem existingItem = getMenuItemById(id);

        existingItem.setName((String) payload.get("name"));
        existingItem.setDescription((String) payload.get("description"));
        existingItem.setCategory((String) payload.get("category"));
        existingItem.setImageUrl((String) payload.get("imageUrl"));

        // Convert Boolean and BigDecimal fields safely
        existingItem.setVeg(Boolean.parseBoolean(payload.get("veg").toString()));
        existingItem.setAvailability(Boolean.parseBoolean(payload.get("availability").toString()));
        existingItem.setPrice(new BigDecimal(payload.get("price").toString()));

        // ✅ Assign restaurant if restaurantId present
        if (payload.containsKey("restaurantId")) {
            Integer restaurantId = (Integer) payload.get("restaurantId");
            Restaurant restaurant = restaurantRepository.findById(restaurantId)
                    .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + restaurantId));
            existingItem.setRestaurant(restaurant);
        }

        return menuItemRepository.save(existingItem);
    }

    // ✅ Delete menu item
    public void deleteMenuItem(int id) {
        if (!menuItemRepository.existsById(id)) {
            throw new EntityNotFoundException("Menu item not found with ID: " + id);
        }
        menuItemRepository.deleteById(id);
    }

    // ✅ Filter menu items
    public List<MenuItem> filterMenuItems(String category, String dietType, String priceRange, String keyword) {
        return menuItemRepository.findAll().stream()
                .filter(item -> category == null || item.getCategory().equalsIgnoreCase(category))
                .filter(item -> {
                    if (dietType == null) return true;
                    return ("veg".equalsIgnoreCase(dietType) && item.isVeg()) ||
                           ("nonveg".equalsIgnoreCase(dietType) && !item.isVeg());
                })
                .filter(item -> {
                    if (priceRange == null) return true;
                    try {
                        String[] parts = priceRange.split("-");
                        double min = Double.parseDouble(parts[0]);
                        double max = (parts.length > 1) ? Double.parseDouble(parts[1]) : Double.MAX_VALUE;
                        return item.getPrice().compareTo(BigDecimal.valueOf(min)) >= 0 &&
                               item.getPrice().compareTo(BigDecimal.valueOf(max)) <= 0;
                    } catch (Exception e) {
                        return false;
                    }
                })
                .filter(item -> {
                    if (keyword == null) return true;
                    String kw = keyword.toLowerCase();
                    return (item.getName() != null && item.getName().toLowerCase().contains(kw)) ||
                           (item.getDescription() != null && item.getDescription().toLowerCase().contains(kw));
                })
                .collect(Collectors.toList());
    }

    // ✅ Get menu items by restaurant ID
    public List<MenuItem> getMenuItemsByRestaurantId(int restaurantId) {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new EntityNotFoundException("Restaurant not found with ID: " + restaurantId));
        return menuItemRepository.findByRestaurant(restaurant);
    }
}
