package com.example.hexaware.hotbyte.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hexaware.hotbyte.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {
}
