package com.example.hexaware.hotbyte.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hexaware.hotbyte.entity.CartItem;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Users;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem, Integer> {

	List<CartItem> findByUser(Users user); 
    List<CartItem> findByUserEmail(String email);
    CartItem findByUserAndMenuItem(Users user, MenuItem menu);
}
