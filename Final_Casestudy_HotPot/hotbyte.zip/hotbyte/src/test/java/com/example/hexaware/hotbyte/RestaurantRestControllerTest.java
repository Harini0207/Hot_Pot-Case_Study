package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.RestaurantRestController;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.RestaurantService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RestaurantRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class RestaurantRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RestaurantService restaurantService;

    @MockBean
    private JwtUtils jwtUtils; 

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(roles = "USER")
    void testGetAllRestaurants() throws Exception {
        Restaurant res = new Restaurant("Spicy Hut", "Chennai", "9999999999", "spicy@hotbyte.com", null, null);
        Mockito.when(restaurantService.getAllRestaurants()).thenReturn(List.of(res));

        mockMvc.perform(get("/api/restaurants"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Spicy Hut"));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testGetRestaurantById() throws Exception {
        Restaurant res = new Restaurant("Spicy Hut", "Chennai", "9999999999", "spicy@hotbyte.com", null, null);
        Mockito.when(restaurantService.getRestaurantById(1)).thenReturn(res);

        mockMvc.perform(get("/api/restaurants/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Spicy Hut"));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testGetRestaurantByEmail() throws Exception {
        Restaurant res = new Restaurant("Tandoori House", "Mumbai", "9876543210", "tandoori@hotbyte.com", null, null);
        Mockito.when(restaurantService.getRestaurantByEmail("tandoori@hotbyte.com")).thenReturn(res);

        mockMvc.perform(get("/api/restaurants/byEmail/tandoori@hotbyte.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("tandoori@hotbyte.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testCreateRestaurant() throws Exception {
        Users owner = new Users("owner@example.com", "pass", "Owner", "9123456789", "Office", "Male");
        Restaurant res = new Restaurant("Burger Place", "Delhi", "8888888888", "burger@hotbyte.com", null, owner);

        Mockito.when(restaurantService.createRestaurant(any(Restaurant.class))).thenReturn(res);

        mockMvc.perform(post("/api/restaurants")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(res)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Burger Place"))
                .andExpect(jsonPath("$.email").value("burger@hotbyte.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testUpdateRestaurant() throws Exception {
        Users owner = new Users("owner@example.com", "pass", "Owner", "9123456789", "Office", "Male");
        Restaurant updated = new Restaurant("Updated Dine", "Hyd", "7777777777", "updated@hotbyte.com", null, owner);

        Mockito.when(restaurantService.updateRestaurant(eq(1), any(Restaurant.class))).thenReturn(updated);

        mockMvc.perform(put("/api/restaurants/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated Dine"))
                .andExpect(jsonPath("$.email").value("updated@hotbyte.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testDeleteRestaurant() throws Exception {
        Mockito.doNothing().when(restaurantService).deleteRestaurant(1);

        mockMvc.perform(delete("/api/restaurants/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Restaurant deleted successfully."));
    }
}
