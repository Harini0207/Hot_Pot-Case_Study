package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.MenuItem;
import com.hexaware.hotbyte.repository.MenuItemRepository;
import com.hexaware.hotbyte.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menu-items")
public class MenuItemRestController {

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    // GET all menu items
    @GetMapping
    public List<MenuItem> getAllMenuItems() {
        return menuItemRepository.findAll();
    }

    // GET a menu item by ID
    @GetMapping("/{id}")
    public MenuItem getMenuItemById(@PathVariable int id) {
        return menuItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found with ID: " + id));
    }

    // POST a new menu item
    @PostMapping
    public MenuItem createMenuItem(@RequestBody MenuItem menuItem) {
        return menuItemRepository.save(menuItem);
    }

    // PUT to update a menu item
    @PutMapping("/{id}")
    public MenuItem updateMenuItem(@PathVariable int id, @RequestBody MenuItem updatedItem) {
        MenuItem existingItem = menuItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found with ID: " + id));

        existingItem.setName(updatedItem.getName());
        existingItem.setDescription(updatedItem.getDescription());
        existingItem.setCategory(updatedItem.getCategory());
        existingItem.setPrice(updatedItem.getPrice());
        existingItem.setImageUrl(updatedItem.getImageUrl());
        existingItem.setVeg(updatedItem.isVeg());
        existingItem.setAvailability(updatedItem.isAvailability());
        existingItem.setRestaurant(updatedItem.getRestaurant());

        return menuItemRepository.save(existingItem);
    }

    // DELETE a menu item
    @DeleteMapping("/{id}")
    public String deleteMenuItem(@PathVariable int id) {
        if (!menuItemRepository.existsById(id)) {
            return "Menu item not found.";
        }
        menuItemRepository.deleteById(id);
        return "Menu item deleted successfully.";
    }

	public RestaurantRepository getRestaurantRepository() {
		return restaurantRepository;
	}

	public void setRestaurantRepository(RestaurantRepository restaurantRepository) {
		this.restaurantRepository = restaurantRepository;
	}
}
