package com.example.hexaware.hotbyte.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.hexaware.hotbyte.entity.Orders;
import com.example.hexaware.hotbyte.entity.Restaurant;
import com.example.hexaware.hotbyte.entity.Users;

import java.util.List;

public interface OrdersRepository extends JpaRepository<Orders, Integer> {
    List<Orders> findByUser(Users user);
    List<Orders> findByRestaurant(Restaurant restaurant);
    List<Orders> findByUserEmail(String email);
    @Query("SELECT o FROM Orders o WHERE o.restaurant.owner.email = :email")
    List<Orders> findByRestaurantEmail(@Param("email") String email);

}
