package com.example.hexaware.hotbyte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotbyteApplicationTests {

	@Test
	void contextLoads() {
	}

}
