package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.PaymentRestController;
import com.example.hexaware.hotbyte.entity.Orders;
import com.example.hexaware.hotbyte.entity.Payment;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.PaymentService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PaymentRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class PaymentRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PaymentService paymentService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser
    void testGetAllPayments() throws Exception {
        Orders order = new Orders();
        order.setId(1);

        Payment payment = new Payment(1, LocalDateTime.now(), new BigDecimal("99.99"), "UPI", "Completed", order);
        Mockito.when(paymentService.getAllPayments()).thenReturn(List.of(payment));

        mockMvc.perform(get("/api/payments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].method").value("UPI"));
    }

    @Test
    @WithMockUser
    void testGetPaymentById() throws Exception {
        Orders order = new Orders();
        order.setId(2);

        Payment payment = new Payment(2, LocalDateTime.now(), new BigDecimal("150.00"), "Card", "Success", order);
        Mockito.when(paymentService.getPaymentById(2)).thenReturn(payment);

        mockMvc.perform(get("/api/payments/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.method").value("Card"))
                .andExpect(jsonPath("$.amount").value(150.00));
    }

    @Test
    @WithMockUser
    void testSavePayment() throws Exception {
        Orders order = new Orders();
        order.setId(3);

        Payment payment = new Payment(0, LocalDateTime.now(), new BigDecimal("250.00"), "Cash", "Pending", order);
        Payment saved = new Payment(10, payment.getPaymentDate(), payment.getAmount(), payment.getMethod(), "Pending", order);

        Mockito.when(paymentService.savePayment(any(Payment.class))).thenReturn(saved);

        mockMvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payment)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.method").value("Cash"));
    }

    @Test
    @WithMockUser
    void testDeletePayment() throws Exception {
        mockMvc.perform(delete("/api/payments/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Payment deleted successfully"));
    }
}
