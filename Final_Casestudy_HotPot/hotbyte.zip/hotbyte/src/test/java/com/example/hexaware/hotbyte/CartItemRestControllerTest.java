package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.CartItemRestController;
import com.example.hexaware.hotbyte.entity.CartItem;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.CartItemService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CartItemRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class CartItemRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CartItemService cartItemService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testGetCartItemsByUser() throws Exception {
        Users user = new Users("john@example.com", "pass", "John", "1234567890", "Street", "Male");
        MenuItem menu = new MenuItem();
        menu.setId(1);
        menu.setName("Burger");
        menu.setPrice(BigDecimal.valueOf(120));

        CartItem item = new CartItem(user, menu, 2);
        item.setId(10);

        Mockito.when(cartItemService.getCartItemsByUser("john@example.com")).thenReturn(List.of(item));

        mockMvc.perform(get("/api/cart/john@example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].quantity").value(2))
                .andExpect(jsonPath("$[0].menuItem.name").value("Burger"));
    }

    @Test
    void testAddCartItem() throws Exception {
        Users user = new Users("jane@example.com", "pass", "Jane", "1234567890", "Street", "Female");
        MenuItem menu = new MenuItem();
        menu.setId(2);
        menu.setName("Pizza");

        CartItem item = new CartItem(user, menu, 1);
        item.setId(11);

        Mockito.when(cartItemService.addCartItem(eq("jane@example.com"), eq(2), eq(1))).thenReturn(item);

        Map<String, String> payload = Map.of(
                "email", "jane@example.com",
                "menuId", "2",
                "quantity", "1"
        );

        mockMvc.perform(post("/api/cart/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(11))
                .andExpect(jsonPath("$.quantity").value(1));
    }

    @Test
    void testUpdateCartItem() throws Exception {
        Users user = new Users("mark@example.com", "pass", "Mark", "1234567890", "Street", "Male");
        MenuItem menu = new MenuItem();
        menu.setId(3);
        menu.setName("Fries");

        CartItem updatedItem = new CartItem(user, menu, 3);
        updatedItem.setId(12);

        Mockito.when(cartItemService.updateCartItem(eq(12), eq(3))).thenReturn(updatedItem);

        mockMvc.perform(put("/api/cart/update/12")
                        .param("quantity", "3"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.quantity").value(3));
    }

    @Test
    void testDeleteCartItem() throws Exception {
        Mockito.doNothing().when(cartItemService).deleteCartItem(13);

        mockMvc.perform(delete("/api/cart/remove/13"))
                .andExpect(status().isOk())
                .andExpect(content().string("Cart item removed successfully."));
    }

    @Test
    void testClearCartForUser() throws Exception {
        Mockito.doNothing().when(cartItemService).clearCartForUser("clear@example.com");

        mockMvc.perform(delete("/api/cart/clear/clear@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().string("Cart cleared for user: clear@example.com"));
    }
}
