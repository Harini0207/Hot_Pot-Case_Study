package com.hexaware.hotbyte.controller;

import com.hexaware.hotbyte.entity.Orders;
import com.hexaware.hotbyte.repository.OrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrdersRestController {

    @Autowired
    private OrdersRepository ordersRepository;

    // GET all orders
    @GetMapping
    public List<Orders> getAllOrders() {
        return ordersRepository.findAll();
    }

    // GET an order by ID
    @GetMapping("/{id}")
    public Orders getOrderById(@PathVariable int id) {
        return ordersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + id));
    }

    // POST a new order
    @PostMapping
    public Orders createOrder(@RequestBody Orders order) {
        return ordersRepository.save(order);
    }

    // DELETE an order
    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable int id) {
        if (!ordersRepository.existsById(id)) {
            return "Order not found.";
        }
        ordersRepository.deleteById(id);
        return "Order deleted successfully.";
    }
}
