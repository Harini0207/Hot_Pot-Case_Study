package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.OrderItemRestController;
import com.example.hexaware.hotbyte.entity.MenuItem;
import com.example.hexaware.hotbyte.entity.OrderItem;
import com.example.hexaware.hotbyte.entity.Orders;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.OrderItemService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrderItemRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class OrderItemRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderItemService orderItemService;

    @MockBean
    private JwtUtils jwtUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser
    void testGetAllOrderItems() throws Exception {
        OrderItem item = new OrderItem();
        item.setId(1);
        item.setQuantity(2);
        item.setPrice(BigDecimal.valueOf(300));

        Mockito.when(orderItemService.getAllOrderItems()).thenReturn(List.of(item));

        mockMvc.perform(get("/api/order-items"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }

    @Test
    @WithMockUser
    void testGetOrderItemById() throws Exception {
        OrderItem item = new OrderItem();
        item.setId(2);
        item.setQuantity(1);
        item.setPrice(BigDecimal.valueOf(150));

        Mockito.when(orderItemService.getOrderItemById(2)).thenReturn(item);

        mockMvc.perform(get("/api/order-items/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(2));
    }

    @Test
    @WithMockUser
    void testCreateOrderItem() throws Exception {
        MenuItem menuItem = new MenuItem();
        menuItem.setId(10);
        menuItem.setName("Burger");

        Orders order = new Orders();
        order.setId(5);

        OrderItem input = new OrderItem();
        input.setMenuItem(menuItem);
        input.setOrder(order);
        input.setQuantity(3);
        input.setPrice(BigDecimal.valueOf(450));

        OrderItem saved = new OrderItem();
        saved.setId(3);
        saved.setMenuItem(menuItem);
        saved.setOrder(order);
        saved.setQuantity(3);
        saved.setPrice(BigDecimal.valueOf(450));

        Mockito.when(orderItemService.createOrderItem(any(OrderItem.class))).thenReturn(saved);

        mockMvc.perform(post("/api/order-items")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.quantity").value(3));
    }

    @Test
    @WithMockUser
    void testUpdateOrderItem() throws Exception {
        MenuItem menuItem = new MenuItem();
        menuItem.setId(10);
        menuItem.setName("Fries");

        Orders order = new Orders();
        order.setId(6);

        OrderItem updated = new OrderItem();
        updated.setQuantity(5);
        updated.setPrice(BigDecimal.valueOf(500));
        updated.setMenuItem(menuItem);
        updated.setOrder(order);

        OrderItem saved = new OrderItem();
        saved.setId(4);
        saved.setQuantity(5);
        saved.setPrice(BigDecimal.valueOf(500));
        saved.setMenuItem(menuItem);
        saved.setOrder(order);

        Mockito.when(orderItemService.updateOrderItem(eq(4), any(OrderItem.class))).thenReturn(saved);

        mockMvc.perform(put("/api/order-items/4")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.quantity").value(5))
                .andExpect(jsonPath("$.price").value(500));
    }

    @Test
    @WithMockUser
    void testDeleteOrderItem() throws Exception {
        Mockito.doNothing().when(orderItemService).deleteOrderItem(7);

        mockMvc.perform(delete("/api/order-items/7"))
                .andExpect(status().isOk())
                .andExpect(content().string("Order item deleted successfully."));
    }
}
