package com.example.hexaware.hotbyte;

import com.example.hexaware.hotbyte.controller.UsersRestController;
import com.example.hexaware.hotbyte.entity.Users;
import com.example.hexaware.hotbyte.security.JwtUtils;
import com.example.hexaware.hotbyte.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsersRestController.class)
@AutoConfigureMockMvc(addFilters = false) 
class UsersRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private JwtUtils jwtUtils; 

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(roles = "ADMIN")
    void testGetAllUsers() throws Exception {
        Users user = new Users("admin@hotbyte.com", "1234", "Admin", "8122369567", "Admin Office", "female");
        user.setRole("admin");

        Mockito.when(userService.getAllUsers()).thenReturn(List.of(user));

        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].email").value("admin@hotbyte.com"));
    }

   
    @Test
    @WithMockUser(roles = "ADMIN")
    void testRegisterUser() throws Exception {
        Users user = new Users("user@example.com", "pass", "User", "9876543210", "Address", "Male");
        user.setRole("user");

        Mockito.when(userService.registerUser(any(Users.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testUpdateUser() throws Exception {
        Users updatedUser = new Users("user@example.com", "newpass", "Updated", "9999999999", "Updated Address", "Male");
        updatedUser.setRole("user");

        Mockito.when(userService.updateUser(eq("user@example.com"), any(Users.class))).thenReturn(updatedUser);

        mockMvc.perform(put("/api/users/user@example.com")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated"))
                .andExpect(jsonPath("$.phone").value("9999999999"));
    }

    @Test
    @WithMockUser(roles = "USER")
    void testGetUserByEmail() throws Exception {
        Users user = new Users("user@example.com", "pass", "User", "9876543210", "Address", "Male");
        user.setRole("user");

        Mockito.when(userService.getUserByEmail("user@example.com")).thenReturn(user);

        mockMvc.perform(get("/api/users/user@example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void testDeleteUser() throws Exception {
        Mockito.when(userService.deleteUser("user@example.com")).thenReturn("User deleted successfully.");

        mockMvc.perform(delete("/api/users/user@example.com"))
                .andExpect(status().isOk())
                .andExpect(content().string("User deleted successfully."));
    }
}
