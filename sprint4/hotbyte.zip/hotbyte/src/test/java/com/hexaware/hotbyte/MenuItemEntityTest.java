package com.hexaware.hotbyte;

public class MenuItemEntityTest {

}
