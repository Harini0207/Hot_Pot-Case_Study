package com.example.hexaware.hotbyte.controller;

import com.example.hexaware.hotbyte.entity.CartItem;
import com.example.hexaware.hotbyte.service.CartItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartItemRestController {

    @Autowired
    private CartItemService cartItemService;

    @GetMapping("/{email}")
    public List<CartItem> getCartItemsByUser(@PathVariable String email) {
        return cartItemService.getCartItemsByUser(email);
    }

    @PostMapping("/add")
    public CartItem addCartItem(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        int menuItemId = Integer.parseInt(payload.get("menuId"));
        int quantity = Integer.parseInt(payload.getOrDefault("quantity", "1"));

        return cartItemService.addCartItem(email, menuItemId, quantity);
    }

    @PutMapping("/update/{id}")
    public CartItem updateCartItem(@PathVariable int id, @RequestParam int quantity) {
        return cartItemService.updateCartItem(id, quantity);
    }

    @DeleteMapping("/remove/{id}")
    public String deleteCartItem(@PathVariable int id) {
        cartItemService.deleteCartItem(id);
        return "Cart item removed successfully.";
    }

    @DeleteMapping("/clear/{email}")
    public String clearCart(@PathVariable String email) {
        cartItemService.clearCartForUser(email);
        return "Cart cleared for user: " + email;
    }
}
